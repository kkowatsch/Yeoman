
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/myGallery/lightbox/css/lightbox.css" />
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/myGallery/gallery.css" />
