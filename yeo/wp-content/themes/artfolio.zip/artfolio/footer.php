<hr>

      <footer>
        <p>&copy; KayKo Designs ~ <?php echo date("Y") ?></p>
      </footer>

    </div> <!-- /container -->

    <?php wp_footer(); ?>

  </body>
</html>