<hr>

      <footer>
        <p>&copy; KayKo Designs ~ <?php echo date("Y") ?></p>
      </footer>
		</div> <!-- /col-md-12 -->
    </div> <!-- /container -->

    <?php wp_footer(); ?>

  </body>
</html>