<hr>
		</div> <!-- Container -->
		<div class="container">
			<footer>
				<p>&copy; KayKo Designs ~ <?php echo date("Y") ?></p>
			</footer>
		</div>
    <?php wp_footer(); ?>

  </body>
</html>